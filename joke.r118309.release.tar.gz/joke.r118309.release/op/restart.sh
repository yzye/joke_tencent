./stop.sh
sleep 1
./start.sh
